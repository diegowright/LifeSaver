//
//  FirstViewController.swift
//  Mobile Computing Project App
//
//  Created by Diego Wright on 3/24/17.
//  Copyright © 2017 Robin Stewart. All rights reserved.
//

import UIKit

class DataVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Instantiate the separate storyboard for Data section and load it
         let storyboard = UIStoryboard(name: "Data", bundle: nil)
         let controller = storyboard.instantiateViewController(withIdentifier: "DataNav") as UIViewController
         addChildViewController(controller)
         view.addSubview(controller.view)
         controller.didMove(toParentViewController: self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
