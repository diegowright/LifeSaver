//
//  NotificationKeys.swift
//  Mobile Computing Project App
//
//  Created by Diego Wright on 4/14/17.
//  Copyright © 2017 Robin Stewart. All rights reserved.
//

import Foundation

// Template Attribute Keys
let addQuestionAtt = "addQuestionAtt"
let addPainLocAtt = "addPainLocAtt"
let addOtherAtt = "addOtherAtt"

let addQuestionData = "addQuestionData"
let addDataKey = "addDataKey"
