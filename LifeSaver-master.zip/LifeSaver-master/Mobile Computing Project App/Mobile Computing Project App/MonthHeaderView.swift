//
//  MonthHeaderView.swift
//  Mobile Computing Project App
//
//  Created by Robin Stewart on 3/24/17.
//  Copyright © 2017 Robin Stewart. All rights reserved.
//

import UIKit
import JTAppleCalendar

class MonthHeaderView: JTAppleHeaderView {
    
    @IBOutlet weak var title: UILabel!
}
